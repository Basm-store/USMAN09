# SIALXD 
rm -rf SIALXD 

git clone https://github.com/M4STERMIND1/SIALXD.git

cd SIALXD

python SIALZADA.py
